import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.css']
})
export class FormsComponent {

  result:string="";

 onSubmit(register:NgForm){
  console.log(register.value);
 }

 display(register:NgForm){
  this.result="First Name:"+register.value.firstname;
  this.result +="<br>Last Name:"+register.value.lastname;
  this.result +="<br>Email:"+register.value.email;
  this.result +="<br>Password:"+register.value.password;

 }

}
