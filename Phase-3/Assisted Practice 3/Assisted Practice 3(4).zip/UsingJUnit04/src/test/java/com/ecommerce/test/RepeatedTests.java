package com.ecommerce.test;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;

import com.ecommerce.method.Calculator;

@DisplayName("JUnit 5 repeated Test Cases")
public class RepeatedTests {

	@BeforeAll
    public static void init(){
        System.out.println("Before All init() method called");
    }
     
    @BeforeEach
    public void initEach(){
        System.out.println("Before Each initEach() method called");
    }

	
	@Test
	@DisplayName("Add operation test")
	@RepeatedTest(5)
	public void addNumber(TestInfo testInfo) {
		Calculator calc=new Calculator();
		Assertions.assertEquals(2, calc.add(1, 1),"1+1 should be equal to 2");
		System.out.println("========addNumber TestCase Executed==========");
	}
	
	
    @AfterEach
    public void cleanUpEach(){
        System.out.println("After Each cleanUpEach() method called");
    }
     
    @AfterAll
    public static void cleanUp(){
        System.out.println("After All cleanUp() method called");
    }

}
