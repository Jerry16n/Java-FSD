package com.test.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.example.entity.ProductEntity;
import com.test.example.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	ProductRepository productRepository;
	
	
	public List<ProductEntity> getAllProducts(){
		return productRepository.findAll();
	}
	public ProductEntity getProduct(int id) {
		return productRepository.findById(id).get();
	}
	public void addProduct(ProductEntity p) {
		productRepository.save(p);
	}
	
	public void updateProduct(int id,ProductEntity pe) {
		if(productRepository.findById(id).isPresent()) {
			ProductEntity oldProduct=productRepository.findById(id).get();
			oldProduct.setName(pe.getName());
			oldProduct.setDescription(pe.getDescription());
			productRepository.save(oldProduct);
		}
	}
	
	public void deleteProduct(int id) {
		productRepository.deleteById(id);
	}
}
