package com.ecommerce.controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.ui.ModelMap;

import com.ecommerce.beans.CustomEventPublisher;

public class MainController {
	
	public String CustomEvent(ModelMap map) {
		String confFile="main-servlet.xml";
		ApplicationContext context=new ClassPathXmlApplicationContext(confFile);
		CustomEventPublisher cvp=(CustomEventPublisher)context.getBean("customEventPublisher");
		cvp.publish();
		cvp.publish();
		return "customEvent";
	}
}
