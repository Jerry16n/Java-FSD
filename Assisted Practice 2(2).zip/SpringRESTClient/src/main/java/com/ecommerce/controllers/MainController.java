package com.ecommerce.controllers;

import org.springframework.web.client.RestTemplate;

import com.ecommerce.beans.Quote;

public class MainController {
	
	public String index() {
		RestTemplate restTemplate=new RestTemplate();
		Quote quote=restTemplate.getForObject("https://gturnquist-quoters.cfapps.io/api/random", Quote.class);
		return quote.toString();
	}
}
