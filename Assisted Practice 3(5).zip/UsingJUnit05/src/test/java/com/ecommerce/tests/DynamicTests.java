package com.ecommerce.tests;

import java.util.Arrays;
import java.util.Collection;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.api.function.Executable;

@DisplayName("JUnit 5 Dynamic Test Example")
public class DynamicTests {

	@TestFactory
	Collection<DynamicTest>dynamicTests(){
		return Arrays.asList(
				dynamicTest("simple dynamic test",()-> assertTrue(true)),
				dynamicTest("My Exeutable Class",new MyExecutable()),
				dynamicTest("Exception Executable",()->{throw new Exception("Exception Example");}),
				dynamicTest("simple dynamic test -2",()-> assertTrue(true))
				);
	}
	


	private DynamicTest dynamicTest(String name, Executable executable) {
        return DynamicTest.dynamicTest(name, executable);
    }



	class MyExecutable implements Executable{

		@Override
		public void execute() throws Throwable {
			System.out.println("Hello World");
			
		}
		
	}
}
