<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Product Details</title>
</head>
<body>
<form action="ProductDetails" method="post">
 <input type="submit" value="Get Details">
 </form>
</body>
</html>