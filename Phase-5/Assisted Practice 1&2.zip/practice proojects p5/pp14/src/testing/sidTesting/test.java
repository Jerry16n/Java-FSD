package testing.sidTesting;
import java.lang.invoke.MethodHandles.Lookup.ClassOption;
import java.net.URL;
import org.openqa.selenium.Platform;
import org.openqa.selenium.remote.DesiredCapabilities;
public class test {

	
	public static void main( String[] args) {
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setBrowserName("chrome");
		cap.setPlatform(platform.WIN10);
	
	URL url = new URL("http://192.168.1.248:4444/wb/hub");
	WebDriver driver = new RemoteWebDriver(url,cap);
	
	driver.get("http://www.google.com");
	System.out.println("Google title: "+driver.getTitle()););
	
	driver.close();
	
	
	}
}
