import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.CallableStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	String jdbcURL = "jdbc:mysql://localhost:3306/sample";
        String username = "root";
        String password = "12345678";

        String user = request.getParameter("username");
        String email = request.getParameter("email");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            // Connect to the database
            
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection connection = DriverManager.getConnection(jdbcURL, username, password);

            // Prepare the SQL call to the stored procedure
            String sql = "{CALL InsertUser(?, ?)}";
            CallableStatement callableStatement = connection.prepareCall(sql);

            // Set the parameters for the stored procedure
            callableStatement.setString(1, user);
            callableStatement.setString(2, email);

            // Execute the stored procedure
            callableStatement.execute();

            out.println("<html><body>");
            out.println("<h1>User inserted successfully!</h1>");
            out.println("</body></html>");

            // Close the resources
            callableStatement.close();
            connection.close();
        } catch (SQLException e) {
            // Handle database-related exceptions
            e.printStackTrace();

            out.println("<html><body>");
            out.println("<h1>Error: " + e.getMessage() + "</h1>");
            out.println("</body></html>");
        } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
    }
}
