const empId=(function(){
    let count=0;
    return function(){
        ++count;
        return `emp${count}`;
    }
})();

console.log("New Emplyee IDs are listed here");
console.log("Alex: "+empId()); 
console.log("Dexter: "+empId()); 
console.log("Annie: "+empId());

console.log("\n");
function fullName(firstName,lastName,callBack){
    console.log("My Name is "+firstName+" "+lastName);
    callBack(lastName);
}

var greeting=function(n){
    console.log("Welcome "+n);
}

fullName("Alex","Wilson",greeting);
console.log("\n");

fullName("Dexter", "Johnson", greeting);
console.log("\n");

fullName("Annie", "Butler", greeting);
