import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { ChildComponent } from './child/child.component';
import { FormsComponent } from './forms/forms.component';
import { PipeExampleComponent } from './pipe-example/pipe-example.component';
import { ProductListComponent } from './product-list/product-list.component';

const routes: Routes = [
  {path:"child",component:ChildComponent},
  {path:"form",component:FormsComponent},
  {path:"pipe",component:PipeExampleComponent},
  {path:"list",component:ProductListComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
