import { Component } from '@angular/core';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent {
  pageTitle:string="Product List Page Property Binding";

  isHeading:boolean=true;
  multipleTable="main"
  reveal:string="";

  onClick(){
    this.reveal="Event Binding has take place successfully";
  }
}
