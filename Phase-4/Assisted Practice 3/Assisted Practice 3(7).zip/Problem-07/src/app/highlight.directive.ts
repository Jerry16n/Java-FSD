import { Directive ,ElementRef,HostListener} from '@angular/core';

@Directive({
  selector: '[appHighlight]'
})
export class HighlightDirective {

  constructor(private high:ElementRef) { }
  @HostListener('mouseenter') onMouseEnter(){
    this.highlight('blue','lightblue','15%');
  }
  @HostListener('mouseleave') onMouseLeave(){
    this.highlight('red','#ffc3c3','30%');
  }


  private highlight(color1:string,color2:string,num:string){
    this.high.nativeElement.style.backgroundColor=color1;
    this.high.nativeElement.style.color=color2;
    this.high.nativeElement.style.width=num;
  }

}
