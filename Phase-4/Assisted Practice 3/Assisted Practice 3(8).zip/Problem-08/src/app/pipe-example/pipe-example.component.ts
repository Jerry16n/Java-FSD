import { Component } from '@angular/core';

@Component({
  selector: 'app-pipe-example',
  templateUrl: './pipe-example.component.html',
  styleUrls: ['./pipe-example.component.css']
})
export class PipeExampleComponent {

  fullname:string = "Nick";
  salary:number = 150000;
  dt:Date = new Date();
  person:object={"pname":"harry", "age":43, "loc":"chennai"};
  fees = 15000;
  val = 0.75;

}
